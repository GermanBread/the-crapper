{
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    nix-systems.url = "github:nix-systems/default";
  };

  outputs = { self, nixpkgs, nix-systems }@inputs: let
    inherit (nixpkgs.lib) genAttrs pipe;
    inherit (nixpkgs) legacyPackages;
    
    forEachSystem = function: pipe (system: function legacyPackages.${system}) [ supportedSystems ];
    supportedSystems = genAttrs (import nix-systems);
  in {
    packages = forEachSystem ({ callPackage, ... }: {
      default = callPackage ./default.nix { };
    });

    devShells = forEachSystem ({ callPackage, ... }: {
      default = callPackage ./shell.nix { inherit inputs; };
    });
  };
}