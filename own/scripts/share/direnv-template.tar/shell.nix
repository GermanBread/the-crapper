{ inputs, mkShellNoCC, nil }:

mkShellNoCC {
  NIX_PATH="nixpkgs=${inputs.nixpkgs}";
  shellHook = ''
    echo "hello, world"
  '';
  packages = [
    nil
  ];
}
