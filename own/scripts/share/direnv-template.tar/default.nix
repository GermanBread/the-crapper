{ stdenvNoCC }:

stdenvNoCC.mkDerivation {
  name = "foobar";
}